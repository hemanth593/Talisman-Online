--[[ Reading game memory --]]


local BC = {}
local bot = require("Bot/bot")
--local cave = require("BC/InsideBC")
function BC.findcourage()
	log("Opening Bag")
send("i")
log("Opened Bag")
wait("2s")
showwindow()
log("Finding Courage")
wait("2s")
local arr, a = findimage (5, 7, 1018, 718, {"Package.bmp"}, 2, 70, 20, 5) -- search for an image, must be in the folder with the pilot
hint (a) -- search result, hint in the lower right corner
if arr then -- if found
    log("Package of Courage Badge Found :" .. #arr)
    for i=1, #arr do
        double_right (arr[i][1], arr[i][2]) -- clicked on each
        wait (1000) -- pause 1000 ms (1 sec)
	log("Courage found")
    end
end
wait(30)
send("i")
wait("2s")
end
function BC.Addteam()
left (867, 58 )
    wait("1s")
    send("f")
    wait("1s")
    left(626, 187 )
    wait("1s")
    right(585, 273 )
    wait("2s")
    left(597, 344 )
    wait("5s")
    start_script (startreseterscritpt)
    wait("1s")
    send("f")
    wait("1s")
end

function convert_epoch_to_normal()
    epoch_time = os.time()
    return os.date("%Y-%m-%d %H:%M:%S", epoch)
end

function calculate_time_difference(epoch1, epoch2)
    return epoch2 - epoch1
end
function convertSecondsToTime(seconds)
    local hours = math.floor(seconds/3600)
    local minutes = math.floor((seconds % 3600) / 60)
    local remainingseconds = seconds % 60 
    log ("Time Take to complete this BC run in minutes :",hours,"h",minutes,"m",remainingseconds,"s")
end
function BC.Leaveteam()
    wait("1s")
   right (39, 41 )
    wait("1s")
   left (96, 91 )
    wait("1s")
end
function BC.StoneCity()
    if bot.getLocation() == "Stone City" and bot.getLocation_cords(0) == "178" and bot.getLocation_cords(1) == "-515"  then
        return 1
    else
        return 0
    end
end
function BC.Invisiblemode()
		BC.Viewreset()
	log("Resetting screen and zoom")
	send ("F12")
	wait("1s")
	send_down ("F12", 1000) -- hold down the 'q' key for 3 seconds (1 sec = 1000 ms.)
	send_down ("@", 1000)
	send_up("F12")
	send_up("@")
	send_down ("{down}", 3000)
	send_up("{down}")
end
function BC.GotoStoneCity()
    while not (bot.getLocation() == "Stone City" and bot.getLocation_cords(0) == "178" and bot.getLocation_cords(1) == "-515") do
        send(stonecitycharm)
        wait(3000)
    end
end
function BC.VastMountain()
    if bot.getLocation() == "White Bear Village" and bot.getLocation_cords(0) == "847" and bot.getLocation_cords(1) == "-606"  then
        return 1
    else
        return 0
    end
end
function BC.Ghostdinwoods()
    if bot.getLocation() == "Ghost Din Woods" and bot.getLocation_cords(0) == "1372" and bot.getLocation_cords(1) == "-417"  then
        return 1
    else
        return 0
    end
end
function BC.Viewreset()
   wait(1000)
   left (866, 61 )     --view reset
   wait(1000)
end
function BC.Surroundings()
   wait(1000)
   left (975, 58 )     --Surroundings
   wait(1000)
   left (560, 541 )
   wait(1000)
end

function BC.start()
epoch1 = os.time()
log("Started BC time :",convert_epoch_to_normal())
while BC.VastMountain() == 0 do
    if BC.StoneCity() == 1 then
        local x = 0
        repeat
    		x = x + 1
            wait(1000)
	    showwindow()
            double_right (474, 465 ) --right click on tele
        until x == 4
        wait(1000)
        left (476, 313 ) --click on top scrollbar if dialouge  box
        wait(1000)
        left (288, 556 ) --click on vast mountain
        wait(4000)
    else
        BC.GotoStoneCity()
    end
end
while BC.Ghostdinwoods() == 0 and BC.VastMountain() == 1  do
    if BC.VastMountain() == 1 then
	BC.Addteam()
	wait("3s")
        local q = 0
        repeat
            q = q + 1
            wait(100)
	     showwindow()
            --double_right (227, 224 )
	     double_right (265, 234 )
		wait(1000)
        until q == 4
        wait(1000)
        left (267, 397 ) -- sell item
        wait(1000)
        local y = 0
        repeat
            y = y + 1
            wait(100)
            left (118, 275 )
            wait(100)
	    if bot.getConfirmBox() == 1 then
	    	wait(100)
            	left (445, 325 )
            	wait(100)
	    end
        until y == 5
        wait(1000)
        left (138, 665)
        wait(1000)
        local z = 0
        repeat
            z = z + 1
            wait(1000)
	    showwindow()
            --double_right (473, 377 )
	    double_right (472, 393 )
            wait(1000)
            double_right (472, 393 )
            wait(1000)
            double_right (472, 393 )
        until z == 2
        wait(1000)
        left (281, 379 )
        wait("4s")
    end
end
wait("4s")
while bot.getLocation() == "Ghost Din Woods" do
    if BC.Ghostdinwoods() == 1 then
        wait(1000)
       	if bot.mount_status() == 0 then
		send(mountkey)
		wait("2s")
    	end
        BC.Surroundings()
        wait(1000)
        send("Skull")
        wait(1000)
        left (330, 265 )
        wait(100)
        while not (bot.getLocation_cords(0) == "423" and bot.getLocation_cords(1) == "53")  do
            if (bot.getLocation_cords(0) == "1395" and bot.getLocation_cords(1) == "-635") then
                wait(100)
                left (404, 540 )
                wait(100)
                local r = 0
                repeat
		    if r == 0 then 
                    	log("Entrance of the Bewitcher Cave")
		    end
                    r = r + 1
		    showwindow()
                    wait(1000)
                    double_right (463, 402 )
                    wait(1000)
                    double_right (464, 435 )
                    wait(1000)
                    double_right (462, 388 )
                    wait(1000)
                until r == 4
                left (277, 362 )
                wait(4000)
            end
        end
    end
end
    if bot.getLocation() == "Bewitcher Cave"  then
        log("Entered Cave:",bot.getLocation())
	BC.InsideBC()
    else
	if bot.mount_status() == 1 then
		send(mountkey)
		wait("2s")
    	end
        wait(1000)
        BC.GotoStoneCity()
    end
end
function BC.attack(attackskills)
	if bot.mount_status() == 1 then
		send(mountkey)
		wait("2s")
    	end
	while bot.Battle_Status() == 1 do
		send("Tab")
		wait(100)
		send(attackskills)
	end
	wait("2s")
end


function BC.InsideBC()
	wait("4s")
	BC.Leaveteam()
	wait("3s")
	while not (bot.getLocation_cords(0) == "397" and bot.getLocation_cords(1) == "76") do
    		if bot.getLocation_cords(0) == "423" and bot.getLocation_cords(1) == "53" then
        		wait(100)
        		right (876, 78 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "369" and bot.getLocation_cords(1) == "78") do
    		if bot.getLocation_cords(0) == "397" and bot.getLocation_cords(1) == "76" then
        		wait(100)
        		right (873, 111 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "357" and bot.getLocation_cords(1) == "107") do
    		if bot.getLocation_cords(0) == "369" and bot.getLocation_cords(1) == "78" then
        		wait(100)
        		right (899, 68 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "333" and bot.getLocation_cords(1) == "133") do
    		if bot.getLocation_cords(0) == "357" and bot.getLocation_cords(1) == "107" then
        		wait(100)
        		right (880, 73 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "326" and bot.getLocation_cords(1) == "164") do
    		if bot.getLocation_cords(0) == "333" and bot.getLocation_cords(1) == "133" then
        		wait(100)
        		right (908, 64 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "302" and bot.getLocation_cords(1) == "180") do
    		if bot.getLocation_cords(0) == "326" and bot.getLocation_cords(1) == "164" then
        		wait(100)
        		right (880, 89 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "271" and bot.getLocation_cords(1) == "168") do
    		if bot.getLocation_cords(0) == "302" and bot.getLocation_cords(1) == "180" then
        		wait(100)
        		right (868, 134 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "237" and bot.getLocation_cords(1) == "158") do
    		if bot.getLocation_cords(0) == "271" and bot.getLocation_cords(1) == "168" then
        		wait(100)
        		right (864, 132 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "221" and bot.getLocation_cords(1) == "163") do
    		if bot.getLocation_cords(0) == "237" and bot.getLocation_cords(1) == "158" then
        		wait(100)
        		right (893, 107 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "184" and bot.getLocation_cords(1) == "165") do
    		if bot.getLocation_cords(0) == "221" and bot.getLocation_cords(1) == "163" then
        		wait(100)
        		right (859, 112 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "150" and bot.getLocation_cords(1) == "163") do
    		if bot.getLocation_cords(0) == "184" and bot.getLocation_cords(1) == "165" then
        		wait(100)
        		right (864, 118 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "125" and bot.getLocation_cords(1) == "145") do
    		if bot.getLocation_cords(0) == "150" and bot.getLocation_cords(1) == "163" then
        		wait(100)
        		right (879, 145 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "108" and bot.getLocation_cords(1) == "120") do
    		if bot.getLocation_cords(0) == "125" and bot.getLocation_cords(1) == "145" then
        		wait(100)
        		right (891, 156 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "107" and bot.getLocation_cords(1) == "95") do
    		if bot.getLocation_cords(0) == "108" and bot.getLocation_cords(1) == "120" then
        		wait(100)
        		right (917, 156 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "86" and bot.getLocation_cords(1) == "67") do
    		if bot.getLocation_cords(0) == "107" and bot.getLocation_cords(1) == "95" then
        		wait(100)
        		right (885, 161 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "82" and bot.getLocation_cords(1) == "37") do
    		if bot.getLocation_cords(0) == "86" and bot.getLocation_cords(1) == "67" then
        		wait(100)
        		right (912, 164 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "109" and bot.getLocation_cords(1) == "20") do
    		if bot.getLocation_cords(0) == "82" and bot.getLocation_cords(1) == "37" then
        		wait(100)
        		right (963, 142 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "125" and bot.getLocation_cords(1) == "-2") do
    		if bot.getLocation_cords(0) == "109" and bot.getLocation_cords(1) == "20" then
        		wait(100)
        		right (945, 152 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "119" and bot.getLocation_cords(1) == "-35") do
    		if bot.getLocation_cords(0) == "125" and bot.getLocation_cords(1) == "-2" then
        		wait(100)
        		right (909, 169 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "142" and bot.getLocation_cords(1) == "-52") do
    		if bot.getLocation_cords(0) == "119" and bot.getLocation_cords(1) == "-35" then
        		wait(100)
        		right (957, 143 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "155" and bot.getLocation_cords(1) == "-66") do
    		if bot.getLocation_cords(0) == "142" and bot.getLocation_cords(1) == "-52" then
        		wait(100)
        		right (940, 138 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "168" and bot.getLocation_cords(1) == "-91") do
    		if bot.getLocation_cords(0) == "155" and bot.getLocation_cords(1) == "-66" then
        		wait(100)
        		right (941, 155 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "191" and bot.getLocation_cords(1) == "-108") do
    		if bot.getLocation_cords(0) == "168" and bot.getLocation_cords(1) == "-91" then
        		wait(100)
        		right (956, 143 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "222" and bot.getLocation_cords(1) == "-97") do
    		if bot.getLocation_cords(0) == "191" and bot.getLocation_cords(1) == "-108" then
        		wait(100)
        		right (970, 97 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "235" and bot.getLocation_cords(1) == "-65") do
    		if bot.getLocation_cords(0) == "222" and bot.getLocation_cords(1) == "-97" then
        		wait(100)
        		right (941, 63 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "229" and bot.getLocation_cords(1) == "-47") do
    		if bot.getLocation_cords(0) == "235" and bot.getLocation_cords(1) == "-65" then
        		wait(100)
        		right (909, 85 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "263" and bot.getLocation_cords(1) == "-45") do
    		if bot.getLocation_cords(0) == "229" and bot.getLocation_cords(1) == "-47" then
        		wait(100)
        		right (974, 112 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "274" and bot.getLocation_cords(1) == "-71") do
    		if bot.getLocation_cords(0) == "263" and bot.getLocation_cords(1) == "-45" then
        		wait(100)
        		right (937, 158 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "297" and bot.getLocation_cords(1) == "-84") do
    		if bot.getLocation_cords(0) == "274" and bot.getLocation_cords(1) == "-71" then
        		wait(100)
        		right (957, 136 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "322" and bot.getLocation_cords(1) == "-64") do
    		if bot.getLocation_cords(0) == "297" and bot.getLocation_cords(1) == "-84" then
        		wait(100)
        		right (960, 83 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "340" and bot.getLocation_cords(1) == "-39") do
    		if bot.getLocation_cords(0) == "322" and bot.getLocation_cords(1) == "-64" then
        		wait(100)
        		right (949, 75 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "350" and bot.getLocation_cords(1) == "-5") do
    		if bot.getLocation_cords(0) == "340" and bot.getLocation_cords(1) == "-39" then
        		wait(100)
        		right (935, 59 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "342" and bot.getLocation_cords(1) == "-27") do
    		if bot.getLocation_cords(0) == "350" and bot.getLocation_cords(1) == "-5" then
        		wait(100)
        		right (906, 61 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "316" and bot.getLocation_cords(1) == "50") do
    		if bot.getLocation_cords(0) == "342" and bot.getLocation_cords(1) == "27" then
        		wait(100)
        		right (877, 77 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "280" and bot.getLocation_cords(1) == "48") do
    		if bot.getLocation_cords(0) == "316" and bot.getLocation_cords(1) == "50" then
        		wait(100)
        		right (861, 118 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "257" and bot.getLocation_cords(1) == "49") do
    		if bot.getLocation_cords(0) == "280" and bot.getLocation_cords(1) == "48" then
        		wait(100)
        		right (882, 113 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "258" and bot.getLocation_cords(1) == "78") do
    		if bot.getLocation_cords(0) == "257" and bot.getLocation_cords(1) == "49" then
        		wait(100)
        		right (920, 68 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "221" and bot.getLocation_cords(1) == "79") do
    		if bot.getLocation_cords(0) == "258" and bot.getLocation_cords(1) == "78" then
        		wait(100)
        		right (859, 113 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "191" and bot.getLocation_cords(1) == "80") do
    		if bot.getLocation_cords(0) == "221" and bot.getLocation_cords(1) == "79" then
        		wait(100)
        		right (870, 114 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "190" and bot.getLocation_cords(1) == "46") do
    		if bot.getLocation_cords(0) == "191" and bot.getLocation_cords(1) == "80" then
        		wait(100)
        		right (918, 170 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "205" and bot.getLocation_cords(1) == "45") do
    		if bot.getLocation_cords(0) == "190" and bot.getLocation_cords(1) == "46" then
        		wait(100)
        		right (943, 116 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "204" and bot.getLocation_cords(1) == "23") do
    		if bot.getLocation_cords(0) == "205" and bot.getLocation_cords(1) == "45" then
        		wait(100)
        		right (918, 151 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "235" and bot.getLocation_cords(1) == "23") do
    		if bot.getLocation_cords(0) == "204" and bot.getLocation_cords(1) == "23" then
        		wait(100)
        		right (970, 115 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "246" and bot.getLocation_cords(1) == "42") do
    		if bot.getLocation_cords(0) == "235" and bot.getLocation_cords(1) == "23" then
        		wait(100)
        		right (937, 84 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "223" and bot.getLocation_cords(1) == "44") do
    		if bot.getLocation_cords(0) == "246" and bot.getLocation_cords(1) == "42" then
        		wait(100)
        		right (881, 111 )
        		--log("1")
        		wait(200)
        		break
    		end
	end

	wait("4s")
	while not (bot.getLocation_cords(0) == "187" and bot.getLocation_cords(1) == "-405") do
    		if bot.getLocation_cords(0) == "223" and bot.getLocation_cords(1) == "44" then
    			local x = 0
        		repeat
	    			showwindow() 
            			x = x + 1
            			wait(100)
            			double_right (88, 111 )
            			wait(100)
            			double_right (104, 144 )
            			wait(100)
            			double_right (155, 104 )
            			wait(100)
            			double_right (156, 116 )
            			wait(100)
        		until x == 3

    			wait(100)
    			left (299, 330 )
    			wait("3s")
    			left (867, 56 )
    			wait(100)
    		end
	end
	while not (bot.getLocation_cords(0) == "190" and bot.getLocation_cords(1) == "-407") do
    		if bot.getLocation_cords(0) == "187" and bot.getLocation_cords(1) == "-405" then
        		wait(100)
        		left (680, 475 )
        		--log("1")
        		wait(200)
        		break
    		end
	end

	while not (bot.getLocation_cords(0) == "165" and bot.getLocation_cords(1) == "-405") do
    		if bot.getLocation_cords(0) == "190" and bot.getLocation_cords(1) == "-407" then
        		wait(100)
        		right (879, 112 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "146" and bot.getLocation_cords(1) == "-406") do
    		if bot.getLocation_cords(0) == "165" and bot.getLocation_cords(1) == "-405" then
        		wait(100)
        		right (888, 116 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "111" and bot.getLocation_cords(1) == "-406") do
    		if bot.getLocation_cords(0) == "146" and bot.getLocation_cords(1) == "-406" then
        		wait(100)
        		right (862, 115 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "76" and bot.getLocation_cords(1) == "-405") do
    		if bot.getLocation_cords(0) == "111" and bot.getLocation_cords(1) == "-406" then
        		wait(100)
        		right (862, 114 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while not (bot.getLocation_cords(0) == "61" and bot.getLocation_cords(1) == "-401") do
    		if bot.getLocation_cords(0) == "76" and bot.getLocation_cords(1) == "-405" then
        		wait(100)
        		right (894, 109 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
    BC.attack(attackskills)
    wait("5s")
    BC.attack(attackskills)
    log("Finished Killing Boss")
    BC.findcourage()
    epoch2 = os.time()
	log("Ended BC Time :", convert_epoch_to_normal() )
	log(convertSecondsToTime(calculate_time_difference(epoch1, epoch2)))
    
end
return BC