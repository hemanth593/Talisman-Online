--[[ Reading game memory --]]

local bot = {}
local CLIENT = 0x00400000
function bot.charName()
    local CLIENT = 0x00400000
    local CHAR_NAME= readmem(0x00400000 +0x00C15980, "d")
    local name = readmem(CHAR_NAME + 0x3C4, "s", 30)

    if string.match(name, "^[%w]+$") then return name
    else
        return readmem(readmem(CHAR_NAME + 0x3C4, "d") + 0x0, "s", 30)
    end
end
function bot.Inventory()
    return readmem(BAG_OPEN_POINTER + 0x240, "d") == 903 and true or false
end

function bot.CHAR_HP()
    return readmem (0x00400000 +0x00C15980, "d")
end
function bot.get_current_HP()
    return readmem(bot.CHAR_HP() + 0x320, "d")
end
function bot.get_percent_HP()
    return readmem(bot.CHAR_HP() + 0x3EC, "b")
end
function bot.get_pethp_skillpoints()
    return readmem(bot.CHAR_HP() + 0x3E8, "d")
end
function bot.get_basic_max_HP()
    return readmem(bot.CHAR_HP() + 0x3E4, "d")
end

function bot.TOTAL_CHAR_MAX_HP()
    local maxhp = floor((((bot.get_percent_HP() - 100) / 100) * (bot.get_basic_max_HP() + bot.get_pethp_skillpoints())) + (bot.get_basic_max_HP() + bot.get_pethp_skillpoints()))
     return maxhp
end

function bot.targetHP()
   return readmem(readmem(readmem(readmem(readmem(readmem(0x00400000 +0x00EBFB40, "d") +  0x18 , "d") + 0x16C , "d") + 0x0 , "d") + 0xC , "d") + 0x3B38 , "d")
end

function bot.targetHPpercent()
        local max = 597
        local min = 460
        local x =  bot.targetHP()
        local c = (100 * (x - min)/137)
        if c < 0 then
            return 0
        else
            return c
        end
end
function bot.getLocation()
    local locationPointers = {0x18, 0x2304, 0xC, 0x1F4, 0x54, 0x54}
    local Location = readmem(0x00400000 +0x00EBFB40, "d")
    for i = 1, #locationPointers
    do
    Location = readmem(Location + locationPointers[i], "d")
    end
    local location = readmem(Location + 0x0, "s", 51)
    local position = regexp(location, [[\[]])
    return string.sub(location, 0, position - 2)
end
function bot.getLocation_cords(p)
    local locationPointers = {0x18, 0x2304, 0xC, 0x1F4, 0x54, 0x54}
    local Location = readmem(CLIENT + 0x00EBFB40, "d")
    for i = 1, #locationPointers
    do
    Location = readmem(Location + locationPointers[i], "d")
    end
    local location = readmem(Location + 0x0, "s", 51)
    local pattern = "%[(-?%d+),(-?%d+)]"
    local a, b = string.match(location, pattern)
    m = p
    if m == 0
        then return a
    end
    if m == 1 then
        return b
    end
end


function bot.getCharLevel()
    return readmem(readmem(0x00400000 +0x00C15980, "d") + 0x32C, "w")
end
function bot.Battle_Status()
    return readmem(readmem(0x00400000 +0x00C15980, "d") + 0x7BC, "b")
end
function bot.Target_Selected()
    local targetSelectedPointers = {0xD0, 0x794, 0x0, 0x24, 0xAC, 0x20}
    local Target_Selected = readmem(CLIENT + 0x00EB5010, "d")
    for i = 1, #targetSelectedPointers
    do
        Target_Selected = readmem(Target_Selected + targetSelectedPointers[i], "d")
    end

    return  readmem(Target_Selected + 0x1AC, "d")
end

function bot.Target_Name()
    local targetNamePointers = {0x18, 0xB1C, 0x0, 0xC, 0xD9C}
    local Target_Name = readmem(CLIENT + 0x012C2D28, "d")
    for i = 1, #targetNamePointers
    do
        Target_Name = readmem(Target_Name + targetNamePointers[i], "d")
    end

    local name = readmem(Target_Name + 0x9AC, "s", 51)

    -- If name is alphanumeric return it safely
    if string.match(name, "^[%w ']+$") then return name
    else
        return readmem(readmem(Target_Name + 0x9AC, "d") + 0x0, "s", 51)
    end
end
function bot.Char_Sit()
    return readmem(CLIENT + 0xC4D8B8, "d")
end
function bot.mount_status()
    mount = readmem(readmem(CLIENT + 0x00C12980, "d") + 0x81C, "d")
    if mount > 0 then
        return 1
    else
        return 0
    end
end

--Tab
function bot.Tab()
    if bot.HP_Percent() < 50 or bot.Mana_Percent < 30 then
            if bot.Battle_Status() == 0 then
                if bot.Char_Sit() == 0 then
                    while bot.HP_Percent() < 95 or bot.Mana_Percent < 95 do
                        send ("56")
                    end
                    wait ("1s")
                    log("Finding mob..")
                    send ("Tab")
                    bot.Battle_decider()
                end
            end
    else
        wait ("1s")
        log("Finding mob..")
        send ("Tab")
        bot.Battle_decider()
    end
end
--Battle
function bot.Battle()
    log("attacking")
    local timer = os.time()
    local timer2 = timer + 15
        while bot.targetHPpercent() > 0 and os.time() < timer2 do
         --   log(bot.targetHPpercent(),os.time(),bot.Target_Selected())
            wait ("1s")
            if bot.targetHPpercent() == 100 and os.time() > timer2 and bot.Target_Selected() == 1 then
                local timer = os.time()
                local timer2 = timer + 15
                log("Target Stucked as more than 5 seconds with full HP")
                Tab()
            end
            send ("222")
            wait(30)
        end
        if bot.targetHPpercent() == 0 then
            log("KILLED")
            log(bot.killed(1))
            bot.Tab()
        end
end
--Battle Decider
function bot.Battle_decider()
    while bot.Target_Selected() == 0 do
        log("Target_Selected :",bot.Target_Name())
        bot.Tab()
    end
    if bot.Target_Selected() == 1 then
        log("Target_Selected :",bot.Target_Name())
        wait("1s")
    end
    while bot.Battle_Status() == 1 do
        log("Somebody else attacking us")
        bot.Battle()
    end
    while bot.HP_Percent() > 50  do
        log("Current_HP of charName()",bot.HP_Percent())
        bot.Battle()
    end
end
--Mana
function bot.Mana()
    return readmem(0x00400000 +0x00C15980, "d")
end
-- Current Mana
function bot.Current_Mana()
    return readmem(bot.Mana() + 0x324, "d")
end
-- Mana buff
function bot.Mana_Buff()
    return readmem(bot.Mana() + 0x2B8, "d")
end
-- Max mana
function bot.Max_Mana()
    return readmem(bot.Mana()  + 0x2B4, "d") + bot.Mana_Buff()
end

--ManaPercent
function bot.Mana_Percent()
   return  ((bot.Current_Mana()/ bot.Max_Mana())*100)
end
--HPPercent
function bot.HP_Percent()
   return  ((bot.get_current_HP()/ bot.TOTAL_CHAR_MAX_HP())*100)
end

local kill = 0

function bot.killed(x)

               kill = kill + x
               log("kill_count :",kill)
end
function bot.Moke_Boss()
    Boss_Name = "Mo Ke's Follower Leader"
     if  bot.Target_Name() == Boss_Name and targetHPpercent() > 0 then
        while bot.Target_Name() == Boss_Name and targetHPpercent() > 0 do
            send ("123123")
         end

     else
         while bot.Target_Name() == Boss_Name and targetHPpercent() == 0 do
                     log(killed(1))
                     wait ("2s")
                     send ("Tab")
                      wait ("2s")
         end
         while (not(bot.Target_Name() == Boss_Name)) do
            send ("Tab")
         end
     end
end
function bot.getConfirmBox()
    return readmem(CLIENT + 0xEC2DA4, "d")
end

function bot.deadbox()
    local dead_box = readmem(CLIENT + 0xC2E894, "d")
    if dead_box > 1 then
        return 0
    end
    if dead_box <= 1 then
        return 1
    end
end
function bot.dead()
   if bot.get_current_HP() < 1 and bot.Battle_Status() == 0 and bot.deadbox() == 1 then
       return 1
   else
       return 0
   end
end

function bot.auto_attack_on_rev(attackkeys)
    if bot.dead() == 1 and bot.getConfirmBox() == 1 then
        left(442, 334)
    else
        if  bot.targetHPpercent() > 0 and bot.Target_Selected() == 1 and bot.dead() == 0 then
            send (attackkeys)
        end
    end
end
function bot.pcp_suwan(attackkeys)
    if bot.dead() == 1  then
        left(508, 467)
    else
        if  bot.targetHPpercent() > 0 and bot.Target_Selected() == 1 and bot.dead() == 0 then
            send (attackkeys)
        end
    end
end


return bot