--[[ Traveling around the map --]]

local travel = {}

local bot = require("Bot/bot")
local getX = bot.getLocation_cords(0)
local getY = bot.getLocation_cords(1)
travel.move = {
	stop = {919, 115},
    right = {920, 115},
    left = {918, 115},
    up = {919, 114},
    down = {919, 116}
}
travel.mouseReset = {900, 182}

travel.bar3 = {538, 754}

travel.resetView = {866, 58}

travel.questPath = {743, 251}

travel.miniMap = {
	minimize = {995, 126},
	maximize = {998, 100}
}

travel.monk = {
	npc = {408, 279},
	enter = {303, 366}
}

travel.exit = {
	npc = {469, 368},
	enter = {303, 381}
}

-- Coordinates to move char through the mini-map
travel.move = {
	stop = {919, 115},
    right = {920, 115},
    left = {918, 115},
    up = {919, 114},
    down = {919, 116}
}


travel.confirmBox = {
    ok = {441, 333},
    cancel = {589, 335}
}

travel.revive = {
	jackstrawok = {442, 334},
	okbutton = {517, 467}
}

travel.avatar = {
	avatar = {48, 50},
	pickMode = {110, 124},
	free = {263, 131}
	}


-- Travels to a specific coordinate via mini-map
function travel.miniMap(xY)    

    while getX() ~= xY[1] or getY() ~= xY[2]
    do  
        local x = getX() local y = getY()
        local via = {travel.move.stop[1], travel.move.stop[2]}
        local repos = {x - xY[1], y - xY[2]}

        -- Check the need of repositioning
        if repos[1] ~= 0 or repos[2] ~= 0 then
            -- X axis
            if repos[1] ~= 0 then via[1] = via[1] - repos[1] end
            -- Y axis
            if repos[2] ~= 0 then via[2] = via[2] + repos[2]end
            -- Travel
            right(via[1], via[2]) 

            -- While char is moving wait
            while true do
                wait(100)
                if getX() == x and getY() == y then break end
                x = getX() y = getY()
            end
        end
    end
    
    -- Reset cursor
    left(travel.mouseReset[1], travel.mouseReset[2]) wait(MS)
end

return travel

