--[[ Reading game memory --]]


local HH = {}
local bot = require("HH/bot")
local mount = 4
local avgwait = "4s"
local viewreset = "867, 59"
local attack = 123
function HH.HHspotoutside()
    if (bot.getLocation() == "Black Wind Camp Dungeon" and bot.getLocation_cords(0) == "-342" and bot.getLocation_cords(1) == "-286") or (bot.getLocation() == "Black Wind Camp Dungeon" and bot.getLocation_cords(0) == "-344" and bot.getLocation_cords(1) == "-283")  then
        return 1
    else
        return 0
    end
end
function HH.leaveteam()
    wait("1s")
   right (39, 41 )
    wait("1s")
   left (96, 91 )
    wait("1s")
end
function HH.HappinessHall(p)
    left (867, 58 )
    wait("1s")
    send("f")
    wait("1s")
    left(626, 187 )
    wait("1s")
    right(582, 274  )
    wait("2s")
    left(611, 410 )
    wait("5s")
    start_script (p)
    wait("5s")
    right (48, 55 )
    wait("2s")
    right (113, 131)
    wait("2s")
    left (247, 135 )
    wait("2s")
    wait("1s")
    send("f")
    wait("1s")
    HH.EnterHHCave()
    HH.leaveteam()
    wait("70s")
end
function HH.HHspotcorrection()
    if HH.HHspotoutside() == 0 then
        left (748, 253 )
        wait ("10s")
    end
end
function HH.EnterHHCave()
    while HH.HHspotoutside() == 0 do 
    	HH.HHspotcorrection()
    end
    if bot.getLocation_cords(0) == "-342" and bot.getLocation_cords(1) == "-286" then
        wait(100)
        double_right  (431, 295 )
     	wait(100)
        double_right  (431, 295 )
        wait(100)
        double_right  (431, 295 )
        wait(100)
        log(bot.getLocation())
        wait("2s")
        log(bot.Target_Name())
        left (300, 365 )
        wait("2s")
    end
    if bot.getLocation_cords(0) == "-344" and bot.getLocation_cords(1) == "-283" then
        wait(100)
        double_right  (517, 382 )
        wait(100)
        double_right  (517, 382 )
        wait(100)
        double_right  (517, 382 )
        wait(100)
        log(bot.getLocation())
        wait("2s")
        log(bot.Target_Name())
        left (300, 365 )
        wait("2s")
    end
    if bot.getLocation() == "Happiness Hall Dungeon" and (bot.getLocation_cords(0) == "55" and bot.getLocation_cords(1) == "33") then
        log("Inside HH Cave :",bot.getLocation(),bot.getLocation_cords(0),bot.getLocation_cords(1))
        wait("2s")
    end
    if bot.mount_status() == 0 then
	send(mount)
	wait("2s")
	HH.MovetoFaYuan()
    end
end

function HH.MovetoFaYuan()
	while not (bot.getLocation_cords(0) == "87" and bot.getLocation_cords(1) == "45") do
    		if bot.getLocation_cords(0) == "55" and bot.getLocation_cords(1) == "33" then
        		wait(100)
        		right (972, 96 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
	while  not (bot.getLocation_cords(0) == "119" and bot.getLocation_cords(1) == "46") do
    		if bot.getLocation_cords(0) == "87" and bot.getLocation_cords(1) == "45" then
        		wait(100)
        		right (972, 114 )
        		--log("2")
        		wait(200)
        		break
    		end
	end

	while  not (bot.getLocation_cords(0) == "141" and bot.getLocation_cords(1) == "74") do
    		if bot.getLocation_cords(0) == "119" and bot.getLocation_cords(1) == "46" then
			wait(100)
			right (955, 70 )
        		--log("3")
        		wait(200)
        		break
		end
	end
	while  not (bot.getLocation_cords(0) == "158" and bot.getLocation_cords(1) == "83") do
		if bot.getLocation_cords(0) == "141" and bot.getLocation_cords(1) == "74" then
			wait(100)
			right (947, 101 )
        		--log("4")
        		wait(200)
        		break
		end
	end
	while  not (bot.getLocation_cords(0) == "179" and bot.getLocation_cords(1) == "91") do
		if bot.getLocation_cords(0) == "158" and bot.getLocation_cords(1) == "83" then
			wait(100)
			right (954, 102 )
         		--log("5")
        		break
		end
	end

	while  not (bot.getLocation_cords(0) == "188" and bot.getLocation_cords(1) == "125") do
		if bot.getLocation_cords(0) == "179" and bot.getLocation_cords(1) == "91" then
			wait(100)
			right (933, 59 )
         		--log("6")
        		break
		end
	end

	while  not (bot.getLocation_cords(0) == "186" and bot.getLocation_cords(1) == "163") do
		if bot.getLocation_cords(0) == "188" and bot.getLocation_cords(1) == "125" then
			wait(100)
			right (915, 53 )
         		--log("7")
        		break
		end
	end

	while  not (bot.getLocation_cords(0) == "206" and bot.getLocation_cords(1) == "188") do
		if bot.getLocation_cords(0) == "186" and bot.getLocation_cords(1) == "163" then
			wait(100)
			right (952, 74 )
         		--log("8")
        		break
		end
	end

	while  not (bot.getLocation_cords(0) == "240" and bot.getLocation_cords(1) == "190") do
		if bot.getLocation_cords(0) == "206" and bot.getLocation_cords(1) == "188" then
			wait(100)
			right (975, 111 )
         		--log("9")
        		break
		end
	end

	while  not (bot.getLocation_cords(0) == "273" and bot.getLocation_cords(1) == "192") do
		if bot.getLocation_cords(0) == "240" and bot.getLocation_cords(1) == "190" then
			wait(100)
			right (973, 111 )
         		--log("10")
        		break
		end
	end

	while  not (bot.getLocation_cords(0) == "274" and bot.getLocation_cords(1) == "172") do
		if bot.getLocation_cords(0) == "273" and bot.getLocation_cords(1) == "192" then
			wait(100)
			right (921, 147 )
         		--log("11")
        		break
		end
	end

	while  not (bot.getLocation_cords(0) == "301" and bot.getLocation_cords(1) == "175") do
		if bot.getLocation_cords(0) == "274" and bot.getLocation_cords(1) == "172" then
			wait(100)
			right (963, 110 )
         		--log("12")
        		break
		end
	end

	while  not (bot.getLocation_cords(0) == "300" and bot.getLocation_cords(1) == "207") do
		if bot.getLocation_cords(0) == "301" and bot.getLocation_cords(1) == "175" then
			wait(100)
			right (917, 62 )
         		--log("13")
        		break
		end
	end

	while  not (bot.getLocation_cords(0) == "318" and bot.getLocation_cords(1) == "206") do
		if bot.getLocation_cords(0) == "300" and bot.getLocation_cords(1) == "207" then
			wait(100)
			right (949, 116 )
    			--log("14")
        		break
		end
	end

	while  not (bot.getLocation_cords(0) == "325" and bot.getLocation_cords(1) == "177") do
		if bot.getLocation_cords(0) == "318" and bot.getLocation_cords(1) == "206" then
			wait(100)
			right (931, 163 )
         		--log("15")
        		wait(200)
        		break
		end
	end


	while  not (bot.getLocation_cords(0) == "322" and bot.getLocation_cords(1) == "141") do
		if bot.getLocation_cords(0) == "325" and bot.getLocation_cords(1) == "177" then
			wait(100)
			right (914, 173 )
         		--log("16")
        		wait(200)
        		break
		end
	end
	while  not (bot.getLocation_cords(0) == "291" and bot.getLocation_cords(1) == "140") do
		if bot.getLocation_cords(0) == "322" and bot.getLocation_cords(1) == "141" then
			wait(100)
			right (868, 117 )
        		wait(200)
         		--log("17")
        		break
		end
	end

	while  not (bot.getLocation_cords(0) == "274" and bot.getLocation_cords(1) == "139") do
		if bot.getLocation_cords(0) == "291" and bot.getLocation_cords(1) == "140" then
			wait(100)
			right (892, 116 )
        		wait("4s")
         		--log("18")
        		break
		end
	end


--		if bot.getLocation_cords(0) == "274" and bot.getLocation_cords(1) == "139" then
--			wait(100)
--			right (892, 116 )
 --      		wait(200)
         		--log("19")
--		end
	HH.attack(70)
	wait("2s")
	HH.MovetoZaton()
end
function HH.MovetoZaton()
    if bot.mount_status() == 0 then
		send(mount)
		wait("2s")
    end
	while not (bot.getLocation_cords(0) == "306" and bot.getLocation_cords(1) == "140") do
    		if bot.getLocation_cords(0) == "274" and bot.getLocation_cords(1) == "139" then
        		wait(100)
        		right (971, 114 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
 	while not (bot.getLocation_cords(0) == "319" and bot.getLocation_cords(1) == "143") do
    		if bot.getLocation_cords(0) == "306" and bot.getLocation_cords(1) == "140" then
        		wait(100)
        		right (941, 110 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
  	while not (bot.getLocation_cords(0) == "344" and bot.getLocation_cords(1) == "132") do
    		if bot.getLocation_cords(0) == "319" and bot.getLocation_cords(1) == "143" then
        		wait(100)
        		right (959, 133 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
   	while not (bot.getLocation_cords(0) == "369" and bot.getLocation_cords(1) == "133") do
    		if bot.getLocation_cords(0) == "344" and bot.getLocation_cords(1) == "132" then
        		wait(100)
        		right (959, 113 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
   	while not (bot.getLocation_cords(0) == "368" and bot.getLocation_cords(1) == "169") do
    		if bot.getLocation_cords(0) == "369" and bot.getLocation_cords(1) == "133" then
        		wait(100)
        		right (918, 56 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
   	while not (bot.getLocation_cords(0) == "368" and bot.getLocation_cords(1) == "189") do
    		if bot.getLocation_cords(0) == "368" and bot.getLocation_cords(1) == "169" then
        		wait(100)
        		right (919, 82 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
   	while not (bot.getLocation_cords(0) == "389" and bot.getLocation_cords(1) == "189") do
    		if bot.getLocation_cords(0) == "368" and bot.getLocation_cords(1) == "189" then
        		wait(100)
        		right (954, 115 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
    while not (bot.getLocation_cords(0) == "404" and bot.getLocation_cords(1) == "173") do
    		if bot.getLocation_cords(0) == "389" and bot.getLocation_cords(1) == "189" then
        		wait(100)
        		right (943, 141 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
    while not (bot.getLocation_cords(0) == "376" and bot.getLocation_cords(1) == "175") do
    		if bot.getLocation_cords(0) == "404" and bot.getLocation_cords(1) == "173" then
        		wait(100)
        		right (874, 111 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
     while not (bot.getLocation_cords(0) == "374" and bot.getLocation_cords(1) == "154") do
    		if bot.getLocation_cords(0) == "376" and bot.getLocation_cords(1) == "175" then
        		wait(100)
        		right (916, 150 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
    while not (bot.getLocation_cords(0) == "393" and bot.getLocation_cords(1) == "153") do
    		if bot.getLocation_cords(0) == "374" and bot.getLocation_cords(1) == "154" then
        		wait(100)
        		right (950, 116 )
        		--log("1")
        		wait(200)
        		break
    		end
	end
     while not (bot.getLocation_cords(0) == "409" and bot.getLocation_cords(1) == "159") do
    		if bot.getLocation_cords(0) == "393" and bot.getLocation_cords(1) == "153" then
        		wait(100)
        		right (945, 105 )
			wait("5s")
        		--log("1")
        		wait(200)
        		break
    		end
	end
    HH.attack(70)
	wait("2s")
    HH.MovetoFinalboss()
 end
function HH.MovetoFinalboss()
    if bot.mount_status() == 0 then
		send(mount)
		wait("2s")
    end
    while not (bot.getLocation_cords(0) == "408" and bot.getLocation_cords(1) == "134") do
        if bot.getLocation_cords(0) == "409" and bot.getLocation_cords(1) == "159" then
            wait(100)
            right (918, 155 )
            --log("1")
            wait(200)
            break
        end
	end
    while not (bot.getLocation_cords(0) == "426" and bot.getLocation_cords(1) == "136") do
        if bot.getLocation_cords(0) == "408" and bot.getLocation_cords(1) == "134" then
            wait(100)
            right (948, 111 )
            --log("1")
            wait(200)
            break
        end
	end
    while not (bot.getLocation_cords(0) == "427" and bot.getLocation_cords(1) == "153") do
        if bot.getLocation_cords(0) == "426" and bot.getLocation_cords(1) == "136" then
            wait(100)
            right (920, 88 )
            --log("1")
            wait(200)
            break
        end
	end
    while not (bot.getLocation_cords(0) == "453" and bot.getLocation_cords(1) == "151") do
        if bot.getLocation_cords(0) == "427" and bot.getLocation_cords(1) == "153" then
            wait(100)
            right (961, 118 )
            --log("1")
            wait(200)
            break
        end
	end
    while not (bot.getLocation_cords(0) == "447" and bot.getLocation_cords(1) == "122") do
        if bot.getLocation_cords(0) == "453" and bot.getLocation_cords(1) == "151" then
            wait(100)
            right (910, 163 )
            --log("1")
            wait(200)
            break
        end
	end
    while not (bot.getLocation_cords(0) == "470" and bot.getLocation_cords(1) == "115") do
        if bot.getLocation_cords(0) == "447" and bot.getLocation_cords(1) == "122" then
            wait(100)
            right (957, 127 )
            --log("1")
            wait(200)
            break
        end
	end
    while not (bot.getLocation_cords(0) == "488" and bot.getLocation_cords(1) == "105") do
        if bot.getLocation_cords(0) == "470" and bot.getLocation_cords(1) == "115" then
            wait(100)
            right (949, 132 )
            --log("1")
            wait(200)
            break
        end
	end
    while not (bot.getLocation_cords(0) == "520" and bot.getLocation_cords(1) == "107") do
        if bot.getLocation_cords(0) == "488" and bot.getLocation_cords(1) == "105" then
            wait(100)
            right (971, 111 )
            --log("1")
            wait("5s")
            break
        end
    end
    HH.attack(70)
 end
function HH.attack(u)
	if bot.mount_status() == 1 then
		send(mount)
		wait("2s")
    	end
	local x = 0
	repeat
    		x = x + 1
		wait(30)
    		send(attack)
		wait(30)
		send("Tab")
		wait(30)
		log(x)
	until x == u --until variable 'x' takes value equal to 100
end
return HH