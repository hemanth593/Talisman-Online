--[[ In-game coordinates --]]

local test = {}
local zaton = {
	{xY = {300, 141}, via = {937, 113}},
	{xY = {319, 143}, via = {937, 113}},
	{xY = {347, 135}, via = {946, 123}},
	{xY = {368, 133}, via = {939, 117}},
	{xY = {367, 167}, via = {918, 82}},
	{xY = {367, 190}, via = {919, 93}},
	{xY = {391, 190}, via = {942, 115}},
	{xY = {393, 180}, via = {921, 125}},
	{xY = {392, 154}, via = {918, 140}}
}

function travelPath(path)
    for _, step in ipairs(path) do
        local xY = step.xY
        local via = step.via

        travel.miniMap(xY)
    end
end

function hh.goToZaton()
	log("Going to Boss Zaton")	
	travelPath(zaton)
end

return test