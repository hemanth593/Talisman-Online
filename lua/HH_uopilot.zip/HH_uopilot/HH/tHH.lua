--[[ Reading game memory --]]


local tHH = {}
local HH = require("HH/HH")
local bot = require("Bot/bot")
function tHH.EnterHHCave()
    while HH.HHspotoutside() == 0 do
    	HH.HHspotcorrection()
    end
    if bot.getLocation_cords(0) == "-342" and bot.getLocation_cords(1) == "-286" then
        wait(100)
        double_right  (431, 295 )
     	wait(100)
        double_right  (431, 295 )
        wait(100)
        double_right  (431, 295 )
        wait(100)
        log(bot.getLocation())
        wait("2s")
        log(bot.Target_Name())
        left (300, 365 )
        wait("2s")
    end
    if bot.getLocation_cords(0) == "-344" and bot.getLocation_cords(1) == "-283" then
        wait(100)
        double_right  (517, 382 )
        wait(100)
        double_right  (517, 382 )
        wait(100)
        double_right  (517, 382 )
        wait(100)
        log(bot.getLocation())
        wait("2s")
        log(bot.Target_Name())
        left (300, 365 )
        wait("2s")
    end
    if bot.getLocation() == "Happiness Hall Dungeon" and (bot.getLocation_cords(0) == "55" and bot.getLocation_cords(1) == "33") then
        log("Inside HH Cave :",bot.getLocation(),bot.getLocation_cords(0),bot.getLocation_cords(1))
        wait("2s")
    end
--    if bot.mount_status() == 0 then
--	send(mount)
--	wait("2s")
--	HH.MovetoFaYuan()
--    end
end
function tHH.accept_team()
   left (433, 336 )
   wait(2000)
end
return tHH