--[[ Reading game memory --]]

local pointers = {}

-- Client base address
local CLIENT = 0x00400000

--[[ Pointer and Offsets --]]
-- HP 
local HP_POINTER = readmem(CLIENT + 0x00C12980, "d")

-- Hp plus
local HP_PLUS_POINTER = readmem(CLIENT + 0x00C12980, "d")

-- Hp buff
local HP_BUFF_POINTER = readmem(CLIENT + 0x00C12980, "d")

-- Max HP
local MAX_HP_POINTER = readmem(CLIENT + 0x00C12980, "d")

-- Mana
local MANA_POINTER = readmem(CLIENT + 0x00C12980, "d")

-- Mana buff
local MANA_BUFF_POINTER = readmem(CLIENT + 0x00C12980, "d")

-- Max mana
local MAX_MANA_POINTER = readmem(CLIENT + 0x00C12980, "d")

-- Char level
local LEVEL_POINTER = readmem(CLIENT + 0x00C12980, "d")

-- Battle status
local BATTLE_STATUS_POINTER = readmem(CLIENT + 0x00C12980, "d")

-- Char name
local CHAR_NAME_POINTER = readmem(CLIENT + 0x00C12980, "d")
--local charNameOffsets = {0x30, 0x0, 0x44, 0x18}
--local CHAR_NAME_POINTER = readmem(CLIENT + 0x00C12980, "d")
--for i = 1, #charNameOffsets 
--do
    --CHAR_NAME_POINTER = 
        --readmem(CHAR_NAME_POINTER + charNameOffsets[i], "d")
--end
function pointers.charName()
    local CLIENT = 0x00400000
    local CHAR_NAME= readmem(CLIENT + 0x00C12980, "d")
    local name = readmem(CHAR_NAME + 0x3C4, "s", 30)

    if string.match(name, "^[%w]+$") then return name
    else
        return readmem(readmem(CHAR_NAME + 0x3C4, "d") + 0x0, "s", 30)
    end
end

-- Target selected
local targetSelectedOffsets = {0xD0, 0x53C, 0x24, 0xF4}
local TARGET_SELECTED_POINTER = readmem(CLIENT + 0x00EB1E28, "d")
for i = 1, #targetSelectedOffsets
do
    TARGET_SELECTED_POINTER = 
        readmem(TARGET_SELECTED_POINTER + targetSelectedOffsets[i], "d")
end

-- Enemey HP
local targetHpOffsets = {0x18, 0x16C, 0x0, 0xC}
local TARGET_HP_POINTER = readmem(CLIENT + 0x00EBFB40, "d")
for i = 1, #targetHpOffsets
do
    TARGET_HP_POINTER = 
        readmem(TARGET_HP_POINTER + targetHpOffsets[i], "d")
end


-- Target name
local targetNameOffsets = {0x18, 0x215C, 0x0, 0x0, 0xC, 0x1F8}
local TARGET_HP_NAME_POINTER = readmem(CLIENT + 0x00EBFB40, "d")
for i = 1, #targetNameOffsets
do
    TARGET_HP_NAME_POINTER = 
        readmem(TARGET_HP_NAME_POINTER + targetNameOffsets[i], "d")
end
function pointers.Target_Name()
    local targetNamePointers = {0x18, 0x215C, 0x0, 0x0, 0xC, 0x1F8}
    local TARGET_HP_NAME = readmem(CLIENT + 0x00EBFB40, "d")
    for i = 1, #targetNamePointers
    do
        TARGET_HP_NAME = readmem(TARGET_HP_NAME + targetNamePointers[i], "d")
    end
        local name = readmem(TARGET_HP_NAME + 0x1254, "s", 51)

    -- If name is alphanumeric return it safely
    if string.match(name, "^[%w ']+$") then return name
    else
        return readmem(readmem(TARGET_HP_NAME + 0x1254, "d") + 0x0, "s", 51)
    end

end
-- X position
local X_POINTER = readmem(CLIENT + 0x00C12980, "d")
--local xOffsets = {0x30, 0x0, 0x44, 0x40}
--local X_POINTER = readmem(CLIENT + 0x00D369DC, "d")
--for i = 1, #xOffsets
--do
    --X_POINTER = readmem(X_POINTER + xOffsets[i], "d")
--end

-- Y position
local Y_POINTER = readmem(CLIENT + 0x00C12980, "d")
--local yOffsets = {0x30, 0x0, 0x44, 0x40}
--local Y_POINTER = readmem(CLIENT + 0x00D369DC, "d")
--for i = 1, #yOffsets
--do
    --Y_POINTER = readmem(Y_POINTER + yOffsets[i], "d")
--end

-- Char location
local locationOffsets = {0x18, 0x2304, 0xC, 0x1F4, 0x54, 0x54}
local LOCATION_POINTER = readmem(CLIENT + 0x00EBFB40, "d")
for i = 1, #locationOffsets
do
    LOCATION_POINTER = 
        readmem(LOCATION_POINTER + locationOffsets[i], "d")
end

-- Mount speed
local MOUNT_SPEED_POINTER = readmem(CLIENT + 0x00C12980, "d")

-- Bag open 
local bagOpenOffsets = {0x18, 0xECC, 0x0, 0xC, 0x1F8}
local BAG_OPEN_POINTER = readmem(CLIENT + 0x00EBFB40, "d")
for i = 1, #bagOpenOffsets
do
    BAG_OPEN_POINTER = 
        readmem(BAG_OPEN_POINTER + bagOpenOffsets[i], "d")
end 

-- Returns your current HP value
function pointers.getHp()
    return readmem(HP_POINTER + 0x320, "d")
end

-- Return hp percent pluses
function pointers.getHpPlus()
    local plus = readmem(HP_PLUS_POINTER + 0x3EC, "b")
    if plus >= 100 then
        return plus - 100
    else
        return plus
    end
end

-- Return hp buffs
function pointers.getHpBuff()
    return readmem(HP_BUFF_POINTER + 0x3E8, "d")
end   

-- Returns your maximum HP value
function pointers.getMaxHp()
    local hp = readmem(MAX_HP_POINTER + 0x3E4, "d") + pointers.getHpBuff() 
    local pluses = pointers.getHpPlus()

    if pluses == 1 then return hp 
    else return math.floor(((hp * pluses) / 100) + hp) end
end

-- Returns your current mana value 
function pointers.getMana()
    return readmem(MANA_POINTER + 0x324, "d")
end

-- Return mana buffs
function pointers.getManaBuff()
    return readmem(MANA_BUFF_POINTER + 0x2B8, "d")
end

-- Returns your maximum mana value
function pointers.getMaxMana()
    return readmem(MAX_MANA_POINTER + 0x2B4, "d") + pointers.getManaBuff()
end

-- Returns char name
function pointers.getCharName()
    local name = readmem(CHAR_NAME_POINTER + 0x3C4, "s", 30)
    
    -- If name is alphanumeric return it safely
    if string.match(name, "^[%w]+$") then return name
    else 
        -- Else read it with offset
        return readmem(readmem(CHAR_NAME_POINTER + 0x3C4, "d") + 0x0, "s", 30)
    end
end

-- Returns true if in battle, false otherwise
function pointers.isInBattle()
    return readmem(BATTLE_STATUS_POINTER + 0x7BC, "b") == 1
end

-- Returns true if target selected, false otherwise
function pointers.isTargetSelected()
    return readmem(TARGET_SELECTED_POINTER + 0x24A0, "d") == 1
end

-- Returns target HP value
function pointers.getTargetHp()
    return readmem(TARGET_HP_POINTER + 0x3B38, "w")
end

-- Returns target name
function pointers.getTargetName()
    local name = readmem(TARGET_HP_NAME_POINTER + 0x1254, "s", 51)

    -- If name is alphanumeric return it safely
    if string.match(name, "^[%w ']+$") then return name
    else 
        return readmem(readmem(TARGET_HP_NAME_POINTER + 0x1254, "d") + 0x0, "s", 51)
    end
end

-- Returns true if target is dead, false otherwise
function pointers.isTargetDead()
    return readmem(TARGET_HP_POINTER + 0x3B38, "w") == 0
end

-- Returns true if target is full health, false otherwise
function pointers.isTargetHpFull()
    return readmem(TARGET_HP_POINTER + 0x3B38, "w") == 597
end

-- Returns char's x-axis location
function pointers.getX()
    local x = readmem(X_POINTER + 0x778, "f") / 20
    return x > 0 and math.floor(x) or math.ceil(x)
end

-- Returns char's y-axis location
function pointers.getY()
    local y = readmem(Y_POINTER + 0x77C, "f") / 20
    return y > 0 and math.floor(y) or math.ceil(y)
end

-- Returns current location
function pointers.getLocation()
    local location = readmem(LOCATION_POINTER + 0x0, "s", 51)
    local position = regexp(location, [[\[]])
    return string.sub(location, 0, position - 2)
end

-- Returns char's level
function pointers.getLevel()
    return readmem(LEVEL_POINTER + 0x32C, "w")
end

-- Return mount speed, 0 if not mounted
function pointers.getMountSpeed()
    return readmem(MOUNT_SPEED_POINTER + 0x81C, "d")
end

-- Returns true if player is mounted
function pointers.isMounted()
    if pointers.getMountSpeed() ~= 0 then return true
    else return false end
end

-- Returns true if there is a confirm box
function pointers.getConfirmBox()
    return readmem(CLIENT + 0xEBFBBC, "d") == 1 and true or false
end

-- Returns true if bag is open
function pointers.isBagOpen()
    return readmem(BAG_OPEN_POINTER + 0x240, "d") == 903 and true or false
end

-- Returns true if sitting, false otherwise
function pointers.isSitting()
    return readmem(CLIENT + 0xC4D8B8, "d") == 1 and true or false
end

return pointers
