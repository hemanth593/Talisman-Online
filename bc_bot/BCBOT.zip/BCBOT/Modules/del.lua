--[[ del main module --]]

local del = {}

local ptr = require("Modules/pointers")
local cycle = require("Modules/cycle")
local util = require("Modules/utility")
local keys = require("Modules/keys")

-- Gets a desired target 
function del.getTarget(farway)

    -- Get target
    log("Let's get a target to kill")
    while not ptr.isTargetSelected() or ptr.isTargetDead() or farway do
        send("tab") wait(MS)
        -- Sit if no mobs around
        --util.sit()
        if farway then break end
    end

end

-- Main function
function del.start(char)

    -- Execute cycles
    cycle.exec(ACTIONS)

    -- Get a target
    -- del.getTarget()
    
    -- Kill target
    -- char.kill()

    -- Reload character resources
    -- if char.level ~= ptr.getLevel() then
    -- wait(W)
    --  util.maxHp = ptr.getMaxHp()
    -- wait(W)
    -- util.maxMana = ptr.getMaxMana()
    -- wait(W)
    -- char.level = ptr.getLevel()
    -- end
	
    -- char.recover()
end

return del