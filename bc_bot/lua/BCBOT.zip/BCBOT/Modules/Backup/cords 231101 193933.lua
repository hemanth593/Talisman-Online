--[[ In-game coordinates --]]

local cords = {}

cords.confirmBox = {
    ok = { 441, 333 }
}

cords.revive = {
	jackstrawok = { 442, 334 },
	okbutton = { 517, 467 }
}

return cords