--[[ Cyclical actions --]]
local cycle = {}

local keys = require("Modules/keys")
local cords = require("Modules/cords")
local deleter = require("Modules/items").delete
local LOW_HP = 0.4
local LOW_MP = 0.4
local BUFF_DELAY = 5
local PET_FOOD_DELAY = 49
local DELETER_BOT = "ON"
local DELETER_DELAY = 0
local MINIMIZED_MODE = "OFF"

-- Adds a new cyclical action to a table
function cycle.add(action, interval, name, t)

    -- Default table of actions
    t = t and t or ACTIONS

    -- Convert period to seconds
    interval = interval * 60

    -- Add new cycle to a table
    -- [1] action (the function)
    -- [2] interval in seconds
    -- [3] when the next cycle should occur
    table.insert(t, {action, interval, os.clock(), name})
end

-- Execute all cycles in accordance to their intervals
function cycle.exec(cycles)
    local clock = os.clock()
    for key, val in pairs(cycles)
    do  
        if clock >= val[3] then
            log("Executing " .. val[4] .. "...")
            val[1]() -- execute cycle
            val[3] = clock + val[2] -- update interval
        end
    end
end

function cycle.petFood()
    wait(S) send(keys.petFood) wait(S)
end

function cycle.buffUp()
    send(keys.buff) wait(S)
end

-- Default periodic actions
ACTIONS = {}
if PET_FOOD_DELAY then cycle.add(cycle.petFood, PET_FOOD_DELAY, "pet food") end
if DELETER_DELAY then cycle.add(deleter, DELETER_DELAY, "deleter") end
if BUFF_DELAY then cycle.add(cycle.buffUp, BUFF_DELAY, "buff") end

return cycle
